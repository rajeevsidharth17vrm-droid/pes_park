import { Router } from "express"
import { z } from "zod"
import { query, withTransaction } from "../db/pool.js"
import { authenticate, adminOnly } from "../middleware/auth.js"
import { generatePlayoffs } from "../services/playoffs.js"

const router = Router()

// Classic "circle method" round-robin: fix one team, rotate the rest each
// round. Produces N-1 rounds (N/2 matches each) covering every pairing
// exactly once — the first half of the season. The second half is derived
// directly from the first half by simply flipping home/away for every
// pairing, guaranteeing they're always exact mirrors of each other, never
// independently generated (which could drift out of sync).
function generateDoubleRoundRobin(teamIds) {
  const teams = [...teamIds]
  const hasBye = teams.length % 2 !== 0
  if (hasBye) teams.push(null) // null = bye slot, that team sits out the round

  const n = teams.length
  const half = n / 2
  const firstHalfRounds = []
  let arr = [...teams]

  for (let r = 0; r < n - 1; r++) {
    const roundPairs = []
    for (let i = 0; i < half; i++) {
      const t1 = arr[i]
      const t2 = arr[n - 1 - i]
      if (t1 !== null && t2 !== null) {
        // Alternate which side is "home" by round parity, purely to avoid
        // one team always sitting on the same side within the first half.
        roundPairs.push(r % 2 === 0 ? [t1, t2] : [t2, t1])
      }
    }
    firstHalfRounds.push(roundPairs)

    // Rotate: keep arr[0] fixed, shift everyone else one position
    const last = arr[n - 1]
    for (let i = n - 1; i > 1; i--) arr[i] = arr[i - 1]
    arr[1] = last
  }

  const secondHalfRounds = firstHalfRounds.map(roundPairs => roundPairs.map(([h, a]) => [a, h]))
  return [...firstHalfRounds, ...secondHalfRounds]
}

const FIXTURE_SELECT = `
  SELECT
    f.id, f.round, f.status,
    f.scheduled_date AS date,
    f.home_score AS "homeScore", f.away_score AS "awayScore",
    f.home_goals AS "homeGoals", f.away_goals AS "awayGoals",
    ht.id AS "homeTeamId", ht.name AS home, NULL AS "homeLogo",
    at.id AS "awayTeamId", at.name AS away, NULL AS "awayLogo"

  FROM fixtures f
  JOIN teams ht ON f.home_team_id = ht.id
  JOIN teams at ON f.away_team_id = at.id
`

// GET /api/fixtures  — all fixtures; optional ?teamId= or ?status=
// GET /api/fixtures — public read (matches standings/players/records being public);
// only creating/editing/deleting fixtures requires admin login (see routes below)
router.get("/", async (req, res, next) => {
  try {
    const { teamId, status } = req.query
    let sql = FIXTURE_SELECT
    const params = []
    const conds = []

    if (teamId) {
      conds.push(`(f.home_team_id = $${params.length + 1} OR f.away_team_id = $${params.length + 1})`)
      params.push(teamId)
    }
    if (status) {
      conds.push(`f.status = $${params.length + 1}`)
      params.push(status)
    }
    if (conds.length) sql += " WHERE " + conds.join(" AND ")
    sql += " ORDER BY f.scheduled_date ASC, f.round ASC"

    const result = await query(sql, params)
    res.json(result.rows)
  } catch (err) { next(err) }
})

// GET /api/fixtures/recent  — last 5 completed (for dashboard widget)
router.get("/recent", async (req, res, next) => {
  try {
    const result = await query(
      FIXTURE_SELECT + " WHERE f.status = 'completed' ORDER BY f.scheduled_date DESC LIMIT 5"
    )
    res.json(result.rows)
  } catch (err) { next(err) }
})

// POST /api/fixtures  — admin creates a fixture
const createSchema = z.object({
  homeTeamId: z.number().int().positive(),
  awayTeamId: z.number().int().positive(),
  round:      z.number().int().positive(),
  date:       z.string(), // YYYY-MM-DD
})

// POST /api/fixtures/generate — auto-creates the full double round-robin
// season schedule from every current team. Always followed by a playoff
// bracket once the group stage completes (format switching removed —
// league_knockout is the only format now).
router.post("/generate", authenticate, adminOnly, async (req, res, next) => {
  try {
    const existingRes = await query("SELECT COUNT(*) FROM fixtures")
    if (parseInt(existingRes.rows[0].count) > 0) {
      return res.status(400).json({ error: "Fixtures already exist. Delete them first if you want to regenerate the schedule." })
    }

    const teamsRes = await query("SELECT id FROM teams ORDER BY id")
    const teamIds = teamsRes.rows.map(r => r.id)
    if (teamIds.length < 2) {
      return res.status(400).json({ error: "Need at least 2 teams to generate a schedule." })
    }

    const rounds = generateDoubleRoundRobin(teamIds)
    let fixturesCreated = 0
    for (let i = 0; i < rounds.length; i++) {
      const roundNumber = i + 1
      for (const [homeId, awayId] of rounds[i]) {
        await query(
          "INSERT INTO fixtures (home_team_id, away_team_id, round, scheduled_date) VALUES ($1, $2, $3, CURRENT_DATE)",
          [homeId, awayId, roundNumber]
        )
        fixturesCreated++
      }
    }

    res.json({ success: true, roundsGenerated: rounds.length, fixturesGenerated: fixturesCreated })
  } catch (err) { next(err) }
})

router.post("/", authenticate, adminOnly, async (req, res, next) => {
  try {
    const { homeTeamId, awayTeamId, round, date } = createSchema.parse(req.body)
    if (homeTeamId === awayTeamId) {
      return res.status(400).json({ error: "Home and away teams must differ" })
    }
    const result = await query(`
      INSERT INTO fixtures (home_team_id, away_team_id, round, scheduled_date)
      VALUES ($1, $2, $3, $4) RETURNING id
    `, [homeTeamId, awayTeamId, round, date])

    const fresh = await query(FIXTURE_SELECT + " WHERE f.id = $1", [result.rows[0].id])
    res.status(201).json(fresh.rows[0])
  } catch (err) { next(err) }
})

// PATCH /api/fixtures/:id/result  — admin enters or re-edits the score
const resultSchema = z.object({
  homeScore: z.number().int().min(0),
  awayScore: z.number().int().min(0),
  homeGoals: z.number().int().min(0),
  awayGoals: z.number().int().min(0),
})

router.patch("/:id/result", authenticate, adminOnly, async (req, res, next) => {
  try {
    const { homeScore, awayScore, homeGoals, awayGoals } = resultSchema.parse(req.body)

    await withTransaction(async ({ query: q }) => {
      // Accept both upcoming AND completed — completed means admin is re-editing
      const fRes = await q("SELECT * FROM fixtures WHERE id = $1", [req.params.id])
      if (!fRes.rows[0]) throw Object.assign(new Error("Fixture not found"), { status: 404 })
      const f = fRes.rows[0]

      const statDelta = (result, scored, conceded) => ({
        won:   result === "win"  ? 1 : 0,
        drawn: result === "draw" ? 1 : 0,
        lost:  result === "loss" ? 1 : 0,
        gf: scored, ga: conceded,
      })

      // If already completed, reverse the old stats using stored goals (not match points)
      if (f.status === "completed") {
        const oldHomeResult = f.home_score > f.away_score ? "win" : f.home_score < f.away_score ? "loss" : "draw"
        const oldAwayResult = oldHomeResult === "win" ? "loss" : oldHomeResult === "loss" ? "win" : "draw"
        const oldHomeGoals  = f.home_goals ?? 0
        const oldAwayGoals  = f.away_goals ?? 0
        for (const [teamId, res, scored, conceded, oldPts] of [
          [f.home_team_id, oldHomeResult, oldHomeGoals, oldAwayGoals, f.home_score],
          [f.away_team_id, oldAwayResult, oldAwayGoals, oldHomeGoals, f.away_score],
        ]) {
          const d = statDelta(res, scored, conceded)
          await q(`
            UPDATE teams SET
              played       = played - 1,
              won          = won - $1, drawn = drawn - $2, lost  = lost - $3,
              gf           = gf  - $4, ga    = ga    - $5,
              score_points = score_points - $7
            WHERE id = $6
          `, [d.won, d.drawn, d.lost, d.gf, d.ga, teamId, oldPts])
        }
      }

      // Save new score + goals + mark completed
      await q(`
        UPDATE fixtures SET home_score = $1, away_score = $2, home_goals = $3, away_goals = $4, status = 'completed'
        WHERE id = $5
      `, [homeScore, awayScore, homeGoals, awayGoals, req.params.id])

      // W/D/L determined by match points
      const homeResult = homeScore > awayScore ? "win" : homeScore < awayScore ? "loss" : "draw"
      const awayResult = homeResult === "win" ? "loss" : homeResult === "loss" ? "win" : "draw"

      // GF/GA uses actual goals, score_points uses actual match scores
      for (const [teamId, res, scored, conceded, matchPts] of [
        [f.home_team_id, homeResult, homeGoals, awayGoals, homeScore],
        [f.away_team_id, awayResult, awayGoals, homeGoals, awayScore],
      ]) {
        const d = statDelta(res, scored, conceded)
        await q(`
          UPDATE teams SET
            played       = played + 1,
            won          = won + $1, drawn = drawn + $2, lost  = lost + $3,
            gf           = gf  + $4, ga    = ga    + $5,
            score_points = score_points + $7
          WHERE id = $6
        `, [d.won, d.drawn, d.lost, d.gf, d.ga, teamId, matchPts])
      }
    })

    // When all fixtures are complete, generate the playoff bracket
    // (moved here from the removed auto-close route — this now fires once
    // an admin manually completes the last fixture's result). Format
    // switching was removed — League + Knockout is the only format.
    const remainingRes = await query(`SELECT COUNT(*) FROM fixtures WHERE status != 'completed'`)
    if (parseInt(remainingRes.rows[0].count) === 0) {
      const seasonRes  = await query("SELECT value FROM app_settings WHERE key = 'current_season'")
      const season     = parseInt(seasonRes.rows[0]?.value || "1")
      await generatePlayoffs(season)
    }

    const fresh = await query(FIXTURE_SELECT + " WHERE f.id = $1", [req.params.id])
    res.json(fresh.rows[0])
  } catch (err) { next(err) }
})

router.patch("/round/:round/date", authenticate, adminOnly, async (req, res, next) => {
  try {
    const { date } = z.object({ date: z.string().min(1) }).parse(req.body)
    const round = parseInt(req.params.round)
    if (isNaN(round)) return res.status(400).json({ error: "Invalid round" })

    const result = await query(
      "UPDATE fixtures SET scheduled_date = $1 WHERE round = $2 RETURNING id",
      [date, round]
    )
    res.json({ updated: result.rows.length, round, date })
  } catch (err) { next(err) }
})

// PATCH /api/fixtures/:id  — admin edits fixture date/round (upcoming only)
const editSchema = z.object({
  round: z.number().int().positive().optional(),
  date:  z.string().optional(),
  homeTeamId: z.number().int().positive().optional(),
  awayTeamId: z.number().int().positive().optional(),
})

router.patch("/:id", authenticate, adminOnly, async (req, res, next) => {
  try {
    const { round, date, homeTeamId, awayTeamId } = editSchema.parse(req.body)

    const result = await query(`
      UPDATE fixtures SET
        round        = COALESCE($1, round),
        scheduled_date = COALESCE($2, scheduled_date),
        home_team_id = COALESCE($3, home_team_id),
        away_team_id = COALESCE($4, away_team_id)
      WHERE id = $5
      RETURNING id
    `, [round ?? null, date ?? null, homeTeamId ?? null, awayTeamId ?? null, req.params.id])

    if (!result.rows[0]) return res.status(404).json({ error: "Fixture not found" })
    const fresh = await query(FIXTURE_SELECT + " WHERE f.id = $1", [req.params.id])
    res.json(fresh.rows[0])
  } catch (err) { next(err) }
})

// DELETE /api/fixtures/:id  — admin deletes fixture
router.delete("/:id", authenticate, adminOnly, async (req, res, next) => {
  try {
    const result = await query(
      "DELETE FROM fixtures WHERE id = $1 RETURNING id", [req.params.id]
    )
    if (!result.rows[0]) return res.status(404).json({ error: "Fixture not found" })
    res.json({ deleted: true })
  } catch (err) { next(err) }
})

export default router