import express from "express"
import cors from "cors"
import dotenv from "dotenv"
dotenv.config()

import authRoutes     from "./routes/auth.js"
import teamRoutes     from "./routes/teams.js"
import playerRoutes   from "./routes/players.js"
import recordRoutes   from "./routes/records.js"
import fixtureRoutes  from "./routes/fixtures.js"
import tradeRoutes    from "./routes/trades.js"
import lineupRoutes   from "./routes/lineup.js"
import favoriteRoutes from "./routes/favorites.js"
import uclRoutes      from "./routes/ucl.js"
import weeklyRoutes      from "./routes/weekly.js"
import quickTournamentRoutes from "./routes/quickTournament.js"
import uclKnockoutRoutes from "./routes/uclKnockout.js"
import duoRoutes         from "./routes/duo.js"
import wctRoutes         from "./routes/wct.js"
import { errorHandler } from "./middleware/errorHandler.js"

const app  = express()
const PORT = process.env.PORT || 3001

// ── Crash guard ───────────────────────────────────────────────────────────────
// Prevent Supabase force-closing a slow connection from taking down the whole
// server. Log the error and keep running — individual requests still fail with
// a 500, but the server stays up for all other requests.
process.on("uncaughtException",  (err) => console.error("[uncaughtException]",  err))
process.on("unhandledRejection", (err) => console.error("[unhandledRejection]", err))

// ── Middleware ────────────────────────────────────────────────────────────────
// CORS_ORIGINS env var: comma-separated list of extra allowed origins.
// The three below are always allowed regardless of env config.
const ALLOWED_ORIGINS = [
  "http://localhost:5173",
  "https://pes-park-opal.vercel.app",
  "https://pes-park-beta.vercel.app",
  ...(process.env.CORS_ORIGINS
    ? process.env.CORS_ORIGINS.split(",").map(o => o.trim()).filter(Boolean)
    : []),
]

app.use(cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (mobile apps, curl, server-to-server)
    if (!origin) return callback(null, true)
    if (ALLOWED_ORIGINS.includes(origin)) return callback(null, true)
    callback(new Error(`CORS: origin '${origin}' not allowed`))
  },
  credentials: true
}))
app.use(express.json({ limit: "15mb" }))

// Request logger (dev only)
if (process.env.NODE_ENV === "development") {
  app.use((req, _res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`)
    next()
  })
}

// ── Routes ────────────────────────────────────────────────────────────────────
app.use("/api/auth",     authRoutes)
app.use("/api/teams",    teamRoutes)
app.use("/api/players",  playerRoutes)
app.use("/api/records",  recordRoutes)
app.use("/api/fixtures", fixtureRoutes)
app.use("/api/trades",   tradeRoutes)
app.use("/api/lineups",  lineupRoutes)
app.use("/api/favorites", favoriteRoutes)
app.use("/api/ucl",    uclRoutes)
app.use("/api/weekly",       weeklyRoutes)
app.use("/api/quick-tournament", quickTournamentRoutes)
app.use("/api/ucl-knockout", uclKnockoutRoutes)
app.use("/api/duo",          duoRoutes)
app.use("/api/wct",          wctRoutes)

// GET /api/settings — public app settings (current season etc.)
app.get("/api/settings", async (_req, res) => {
  try {
    const result = await query("SELECT key, value FROM app_settings")
    const settings = Object.fromEntries(result.rows.map(r => [r.key, r.value]))
    res.json(settings)
  } catch (err) {
    res.json({ current_season: "1" })
  }
})

// PATCH /api/settings — admin updates settings
app.patch("/api/settings", authenticate, adminOnly, async (req, res) => {
  try {
    const { key, value } = req.body
    await query(
      "INSERT INTO app_settings (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = $2",
      [key, String(value)]
    )
    res.json({ key, value })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// One-off admin utility — recalculates market_value for ALL players using the
// full corrected JS formula (both sides + BDR). Hit once after deploying the
// marketValue.js fix to correct stale MVs. Admin auth required.
import { query } from "./db/pool.js"
import { recalcMarketValue, recalcBestPlayer } from "./services/marketValue.js"
import { authenticate, adminOnly } from "./middleware/auth.js"

app.post("/admin/recalc-mv", authenticate, adminOnly, async (req, res) => {
  try {
    // Recalculate every player who has ever appeared in a match, using the
    // single real formula in services/marketValue.js (uncapped — no ceiling,
    // includes the BDR swing) — the exact same logic that runs after every
    // individual match result, so a bulk recalc here can never drift out of
    // sync with the per-match path the way a separately hand-written SQL
    // version could.
    const idsRes = await query(`
      SELECT DISTINCT id FROM (
        SELECT player_id AS id FROM match_records
        UNION
        SELECT opponent_id FROM match_records
      ) sub
    `)
    const ids = idsRes.rows.map(r => r.id)

    for (const id of ids) {
      await recalcMarketValue(id)
      await recalcBestPlayer(id)
      // BDR is now tournament-placement only — recalcBdrFromMatches is no longer called
    }

    res.json({ success: true, updated: ids.length, message: `Recalculated MV, BDR, and Best Player for ${ids.length} players` })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── League Info board (public read, admin write) ───────────────────────────
app.get("/api/league-info", async (_req, res) => {
  try {
    const result = await query("SELECT * FROM league_info ORDER BY sort_order ASC, id ASC")
    res.json(result.rows)
  } catch (err) { res.status(500).json({ error: err.message }) }
})
app.post("/api/league-info", authenticate, adminOnly, async (req, res) => {
  try {
    const { title, content, sortOrder } = req.body
    const result = await query(
      "INSERT INTO league_info (title, content, sort_order) VALUES ($1,$2,$3) RETURNING *",
      [title, content, sortOrder ?? 0]
    )
    res.status(201).json(result.rows[0])
  } catch (err) { res.status(500).json({ error: err.message }) }
})
app.patch("/api/league-info/:id", authenticate, adminOnly, async (req, res) => {
  try {
    const { title, content, sortOrder } = req.body
    const result = await query(
      "UPDATE league_info SET title=$1, content=$2, sort_order=$3 WHERE id=$4 RETURNING *",
      [title, content, sortOrder ?? 0, req.params.id]
    )
    res.json(result.rows[0])
  } catch (err) { res.status(500).json({ error: err.message }) }
})
app.delete("/api/league-info/:id", authenticate, adminOnly, async (req, res) => {
  try {
    await query("DELETE FROM league_info WHERE id=$1", [req.params.id])
    res.json({ deleted: true })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// 404 handler
app.use((_req, res) => res.status(404).json({ error: "Route not found" }))

// Global error handler (must be last)
app.use(errorHandler)

app.listen(PORT, () => {
  console.log(`\n🚀 Server running on port ${PORT}`)
  console.log(`   Env: ${process.env.NODE_ENV || "development"}`)
  console.log(`   DB:  ${process.env.DATABASE_URL ? "connected" : "⚠️  DATABASE_URL not set"}`)
})